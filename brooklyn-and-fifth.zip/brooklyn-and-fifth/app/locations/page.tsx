import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { agency, locations, photoCredits } from "@/data/fictional-data";
import { MapPlate } from "@/components/MapPlate";
import { Reveal, CutLine } from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Find us",
  description:
    "Two rooms, one river apart. Both addresses are invented for this demonstration.",
};

export default function LocationsPage() {
  const [bk, ff] = locations;

  return (
    <div className="min-h-screen bg-bk-ink">
      <nav className="fixed inset-x-0 top-0 z-50 flex items-center justify-between border-b border-bk-brass/20 bg-bk-ink/90 px-5 py-4 backdrop-blur-md sm:px-8 lg:px-12">
        <Link href="/" className="font-slab text-xl uppercase tracking-rivet text-bk-paper">
          Brooklyn <span className="text-bk-brass">&amp;</span> Fifth
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/brooklyn" className="stamp text-bk-paper/60 hover:text-bk-brass">
            Shop
          </Link>
          <Link href="/fifth" className="stamp text-bk-paper/60 hover:text-bk-brass">
            Salon
          </Link>
          <Link href="/book" className="stamp bg-bk-brass px-4 py-2 text-bk-ink">
            Book
          </Link>
        </div>
      </nav>

      <main id="main">
      {/* ------------------------------------------------------------ header */}
      <section className="tex-brick tex-grain px-5 pb-16 pt-36 sm:px-8 sm:pt-44 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          <h1 className="font-slab text-mega uppercase leading-[0.84] text-bk-paper">
            <CutLine>Two rooms,</CutLine>
            <CutLine delay={0.08}>
              <span className="text-bk-brass">one river</span>
            </CutLine>
          </h1>
          <p className="mt-8 max-w-measure font-grot text-xl leading-relaxed text-bk-paper/70">
            Eleven kilometres and about forty minutes on the subway, depending on which
            train is running that day.
          </p>
        </div>
      </section>

      {/* ---------------------------------------------------------- Brooklyn */}
      <section className="tex-brick px-5 pb-24 sm:px-8 lg:px-12" aria-labelledby="loc-bk">
        <div className="mx-auto grid max-w-[92rem] gap-10 lg:grid-cols-2 lg:gap-14">
          <Reveal>
            <div className="relative aspect-[4/3] w-full overflow-hidden border border-bk-brass/25">
              <MapPlate universe="brooklyn" label={bk.name} />
            </div>
            <div className="relative mt-6 aspect-[16/9] w-full overflow-hidden bg-bk-smoke">
              <Image
                src={bk.image}
                alt={bk.imageAlt}
                fill
                sizes="(max-width: 1024px) 100vw, 46vw"
                className="object-cover saturate-[0.6]"
              />
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <h2 id="loc-bk" className="font-slab text-huge uppercase leading-[0.9] text-bk-paper">
              {bk.name}
            </h2>
            <p className="mt-6 font-grot text-2xl leading-snug text-bk-brass">
              {bk.street}
              <span className="mt-1 block text-bk-paper/60">{bk.city}</span>
            </p>

            <dl className="mt-9 space-y-3">
              {bk.hours.map((h) => (
                <div key={h.day} className="rule-brass flex flex-wrap justify-between gap-4 pt-3">
                  <dt className="stamp text-bk-paper/50">{h.day}</dt>
                  <dd className="font-grot text-xl text-bk-paper">{h.open}</dd>
                </div>
              ))}
            </dl>

            <p className="mt-8 max-w-measure font-grot text-xl leading-relaxed text-bk-paper/70">
              {bk.note}
            </p>

            <p className="stamp mt-6 text-bk-paper/45">{bk.subway}</p>
            <p className="mt-2 font-grot text-xl text-bk-paper">{bk.phone}</p>

            <Link
              href="/book"
              className="stamp mt-8 inline-block bg-bk-brass px-7 py-3.5 text-bk-ink transition-colors hover:bg-bk-paper"
            >
              Book the Brooklyn room
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ------------------------------------------------------------- Fifth */}
      <section className="tex-stock px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="loc-ff">
        <div className="u-fifth mx-auto grid max-w-[92rem] gap-10 lg:grid-cols-2 lg:gap-14">
          <Reveal delay={0.1} className="lg:order-2">
            <div className="relative aspect-[4/3] w-full overflow-hidden border border-ff-noir/15">
              <MapPlate universe="fifth" label={ff.name} />
            </div>
            <div className="relative mt-6 aspect-[16/9] w-full overflow-hidden bg-ff-champagne/30">
              <Image
                src={ff.image}
                alt={ff.imageAlt}
                fill
                sizes="(max-width: 1024px) 100vw, 46vw"
                className="object-cover"
              />
            </div>
          </Reveal>

          <Reveal className="lg:order-1">
            <h2 id="loc-ff" className="font-didone text-huge leading-[0.9] text-ff-noir">
              {ff.name}
            </h2>
            <p className="mt-6 font-garamond text-2xl leading-snug text-ff-rouge">
              {ff.street}
              <span className="mt-1 block text-ff-noir/60">{ff.city}</span>
            </p>

            <dl className="mt-9 space-y-3">
              {ff.hours.map((h) => (
                <div key={h.day} className="rule-hair flex flex-wrap justify-between gap-4 pt-3">
                  <dt className="stamp text-ff-noir/50">{h.day}</dt>
                  <dd className="font-garamond text-xl text-ff-noir">{h.open}</dd>
                </div>
              ))}
            </dl>

            <p className="mt-8 max-w-measure-serif font-garamond text-xl leading-relaxed text-ff-noir/70">
              {ff.note}
            </p>

            <p className="stamp mt-6 text-ff-noir/45">{ff.subway}</p>
            <p className="mt-2 font-garamond text-xl text-ff-noir">{ff.phone}</p>

            <Link
              href="/book"
              className="stamp mt-8 inline-block bg-ff-noir px-7 py-3.5 text-ff-chalk transition-colors hover:bg-ff-rouge"
            >
              Request the Fifth room
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ----------------------------------------------------------- credits */}
      <section className="bg-bk-ink px-5 py-20 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          <h2 className="font-slab text-3xl uppercase text-bk-paper">Photography</h2>
          <p className="mt-4 max-w-measure font-grot text-lg leading-relaxed text-bk-paper/60">
            Every photograph in this build comes from Unsplash and belongs to the person
            who took it. In rough order of appearance: {photoCredits.join(", ")}.
          </p>
          <p className="stamp mt-10 text-bk-brass/70">{agency.signature}</p>
        </div>
      </section>
      </main>
    </div>
  );
}
