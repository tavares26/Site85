import type { Metadata } from "next";
import { SplitEntry } from "@/components/SplitEntry";

export const metadata: Metadata = {
  title: "Brooklyn & Fifth — Choose your house",
  description: "A barbershop in Brooklyn. A beauty salon on Fifth. Pick a side.",
};

export default function EntryPage() {
  return <SplitEntry />;
}
