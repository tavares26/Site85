import type { Metadata } from "next";
import { RazorServices } from "@/components/RazorServices";
import { ThisIsADemonstration } from "@/components/AgencyMarks";

export const metadata: Metadata = {
  title: "Services",
  description: "Six services, four chairs, no packages and no upsell at the register.",
};

export default function BrooklynServicesPage() {
  return (
    <>
      <div className="pt-20" />
      <RazorServices />
      <ThisIsADemonstration universe="brooklyn" />
    </>
  );
}
