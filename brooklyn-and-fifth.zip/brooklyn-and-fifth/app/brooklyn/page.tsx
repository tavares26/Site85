import Image from "next/image";
import Link from "next/link";
import { BrooklynHero } from "@/components/BrooklynHero";
import { BeforeAfterSlider } from "@/components/BeforeAfterSlider";
import { ThisIsADemonstration } from "@/components/AgencyMarks";
import { Reveal, CutLine } from "@/components/Reveal";
import {
  barbers,
  brooklynBeforeAfter,
  brooklynServices,
  brooklynWall,
  testimonials,
} from "@/data/fictional-data";

export default function BrooklynHome() {
  const voices = testimonials.filter((t) => t.universe === "brooklyn");

  return (
    <>
      <BrooklynHero />

      {/* -------------------------------------------------------- statement */}
      <section className="tex-brick tex-grain relative px-5 py-24 sm:px-8 sm:py-32 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          <Reveal>
            <p className="max-w-[22ch] font-slab text-huge uppercase leading-[0.92] text-bk-paper">
              A haircut is
              <span className="text-bk-brass"> forty minutes </span>
              of someone paying attention to you.
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-8 max-w-measure font-grot text-xl leading-relaxed text-bk-paper/65">
              That is the entire pitch. We do not sell product at the register, we do not
              run a loyalty app and nobody here will ask what you do for work unless you
              bring it up first.
            </p>
          </Reveal>
        </div>
      </section>

      {/* ---------------------------------------------------- meet the barbers */}
      <section className="bg-bk-smoke px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="bk-team">
        <div className="mx-auto max-w-[92rem]">
          <div className="mb-12 flex flex-wrap items-end justify-between gap-6">
            <h2 id="bk-team" className="font-slab text-colossal uppercase text-bk-paper">
              <CutLine>Meet the</CutLine>
              <CutLine delay={0.08}>
                <span className="text-bk-brass">barbers</span>
              </CutLine>
            </h2>
            <Link href="/brooklyn/barbers" className="stamp link-underline text-bk-brass">
              All four, in full
            </Link>
          </div>

          <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {barbers.map((b, i) => (
              <Reveal as="li" key={b.id} delay={i * 0.06}>
                <Link href="/brooklyn/barbers" className="group block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-bk-ink">
                    <Image
                      src={b.portrait}
                      alt={`${b.name}, ${b.role}`}
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 24vw"
                      className="object-cover saturate-[0.6] transition-[transform,filter] duration-[900ms] ease-blade group-hover:scale-[1.05] group-hover:saturate-100"
                    />
                    <span className="stamp absolute bottom-0 left-0 bg-bk-brass px-3 py-1.5 text-bk-ink">
                      {b.chair}
                    </span>
                  </div>
                  <h3 className="mt-4 font-slab text-2xl uppercase text-bk-paper">{b.name}</h3>
                  <p className="mt-1 font-grot text-lg text-bk-paper/55">{b.specialties[0]}</p>
                </Link>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* ------------------------------------------------------- services cut */}
      <section className="tex-brick px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="bk-svc">
        <div className="mx-auto max-w-[92rem]">
          <h2 id="bk-svc" className="font-slab text-colossal uppercase text-bk-paper">
            <CutLine>The list</CutLine>
          </h2>

          <ul className="mt-10">
            {brooklynServices.slice(0, 4).map((s) => (
              <li key={s.id} className="rule-brass py-5">
                <Link
                  href="/brooklyn/services"
                  className="group flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1"
                >
                  <span className="font-slab text-3xl uppercase text-bk-paper transition-colors group-hover:text-bk-brass sm:text-4xl">
                    {s.name}
                  </span>
                  <span className="stamp text-bk-paper/50">
                    {s.duration} min · ${s.price}
                  </span>
                </Link>
              </li>
            ))}
          </ul>

          <Link
            href="/brooklyn/services"
            className="stamp mt-10 inline-flex items-center gap-3 border border-bk-brass/50 px-6 py-3.5 text-bk-brass transition-colors hover:bg-bk-brass hover:text-bk-ink"
          >
            Open the razor
            <svg width="22" height="8" viewBox="0 0 22 8" fill="none" aria-hidden>
              <path d="M0 4h20M16 1l4 3-4 3" stroke="currentColor" strokeWidth="1.2" />
            </svg>
          </Link>
        </div>
      </section>

      {/* ------------------------------------------------ fresh from the chair */}
      <section className="bg-bk-smoke px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="bk-ba">
        <div className="mx-auto max-w-[92rem]">
          <h2 id="bk-ba" className="font-slab text-colossal uppercase text-bk-paper">
            <CutLine>Fresh from</CutLine>
            <CutLine delay={0.08}>
              <span className="text-bk-brass">the chair</span>
            </CutLine>
          </h2>
          <p className="mt-6 max-w-measure font-grot text-xl text-bk-paper/65">
            Drag the handle, or use the arrow keys once it has focus.
          </p>

          <div className="mt-12 grid gap-12 lg:grid-cols-3 lg:gap-8">
            {brooklynBeforeAfter.map((b, i) => (
              <Reveal key={b.id} delay={i * 0.08}>
                <BeforeAfterSlider item={b} universe="brooklyn" />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* -------------------------------------------------------- the wall */}
      <section className="tex-brick tex-grain px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="bk-wall">
        <div className="mx-auto max-w-[92rem]">
          <div className="mb-12 flex flex-wrap items-end justify-between gap-6">
            <h2 id="bk-wall" className="font-slab text-colossal uppercase text-bk-paper">
              <CutLine>The wall</CutLine>
            </h2>
            <Link href="/brooklyn/gallery" className="stamp link-underline text-bk-brass">
              Everything that is pinned up
            </Link>
          </div>

          <ul className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {brooklynWall.slice(0, 4).map((w, i) => (
              <Reveal as="li" key={w.id} delay={i * 0.05}>
                <figure
                  className="bg-bk-paper p-2 pb-8 shadow-[0_18px_40px_-24px_rgba(0,0,0,0.9)] transition-transform duration-700 ease-blade hover:rotate-0"
                  style={{ transform: `rotate(${w.tilt}deg)` }}
                >
                  <div className="relative aspect-square w-full overflow-hidden bg-bk-ink">
                    <Image
                      src={w.src}
                      alt={w.alt}
                      fill
                      sizes="(max-width: 640px) 45vw, 22vw"
                      className="object-cover saturate-[0.65]"
                    />
                  </div>
                  <figcaption className="mt-2 px-1 font-grot text-sm text-bk-ink/70">
                    {w.caption}
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* ------------------------------------------------------- the voices */}
      <section className="bg-bk-wine px-5 py-20 sm:px-8 sm:py-28 lg:px-12">
        <div className="mx-auto grid max-w-[92rem] gap-10 sm:grid-cols-2 lg:gap-16">
          {voices.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.1}>
              <blockquote>
                <p className="font-grot text-2xl italic leading-snug text-bk-paper sm:text-3xl">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <footer className="stamp mt-5 text-bk-paper/60">
                  {t.name}, {t.detail}
                </footer>
              </blockquote>
            </Reveal>
          ))}
        </div>
      </section>

      {/* -------------------------------------------------------- cross over */}
      <section className="bg-bk-ink px-5 py-20 sm:px-8 lg:px-12">
        <Link
          href="/fifth"
          className="group mx-auto flex max-w-[92rem] flex-wrap items-center justify-between gap-6 border border-bk-brass/25 p-8 transition-colors hover:border-bk-brass/70 sm:p-12"
        >
          <div>
            <p className="stamp text-bk-brass">The other house</p>
            <p className="mt-3 font-didone text-4xl italic text-bk-paper sm:text-5xl">
              Fifth Avenue
            </p>
            <p className="mt-2 font-garamond text-xl text-bk-paper/60">
              New York looks good on you.
            </p>
          </div>
          <span className="stamp flex items-center gap-3 text-bk-paper/70 transition-colors group-hover:text-bk-brass">
            Cross the river
            <svg width="34" height="8" viewBox="0 0 34 8" fill="none" aria-hidden>
              <path d="M0 4h32M28 1l4 3-4 3" stroke="currentColor" strokeWidth="1.2" />
            </svg>
          </span>
        </Link>
      </section>

      <ThisIsADemonstration universe="brooklyn" />
    </>
  );
}
