import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { brooklynWall } from "@/data/fictional-data";
import { ThisIsADemonstration } from "@/components/AgencyMarks";
import { Reveal, CutLine } from "@/components/Reveal";

export const metadata: Metadata = {
  title: "The Wall",
  description:
    "Everything pinned to the west wall of the Brooklyn room since 2016.",
};

export default function WallPage() {
  return (
    <>
      <section className="tex-brick tex-grain px-5 pb-10 pt-36 sm:px-8 sm:pt-44 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          <h1 className="font-slab text-mega uppercase leading-[0.84] text-bk-paper">
            <CutLine>The</CutLine>
            <CutLine delay={0.08}>
              <span className="text-bk-brass">wall</span>
            </CutLine>
          </h1>
          <p className="mt-8 max-w-measure font-grot text-xl leading-relaxed text-bk-paper/70">
            The west side of the shop, floor to ceiling. Nothing here is for sale and
            nothing gets taken down, which is why it now runs onto the ceiling.
          </p>
        </div>
      </section>

      {/* A real wall is not a grid. Columns give it uneven heights, the tilt
          values in the data give it the pinned-up look. */}
      <section className="tex-brick px-5 pb-28 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-[92rem] columns-1 gap-6 sm:columns-2 lg:columns-3 [&>*]:mb-8">
          {brooklynWall.map((w, i) => (
            <Reveal key={w.id} delay={(i % 3) * 0.07}>
              <figure
                className="break-inside-avoid bg-bk-paper p-3 pb-10 shadow-[0_26px_60px_-32px_rgba(0,0,0,0.95)] transition-transform duration-700 ease-blade hover:rotate-0 hover:scale-[1.015]"
                style={{ transform: `rotate(${w.tilt}deg)` }}
              >
                <div
                  className={`relative w-full overflow-hidden bg-bk-ink ${
                    w.span === "tall"
                      ? "aspect-[3/4]"
                      : w.span === "wide"
                        ? "aspect-[4/3]"
                        : "aspect-square"
                  }`}
                >
                  <Image
                    src={w.src}
                    alt={w.alt}
                    fill
                    sizes="(max-width: 640px) 92vw, (max-width: 1024px) 46vw, 30vw"
                    className="object-cover saturate-[0.7]"
                  />
                </div>
                <figcaption className="mt-3 flex items-baseline justify-between gap-3 px-1">
                  <span className="font-grot text-lg text-bk-ink">{w.caption}</span>
                  <span className="stamp shrink-0 text-bk-ink/45">{w.meta}</span>
                </figcaption>
              </figure>
            </Reveal>
          ))}

          {/* One pinned note, hand-written into the wall rather than photographed */}
          <Reveal>
            <div
              className="break-inside-avoid border border-bk-brass/40 bg-bk-wine p-8"
              style={{ transform: "rotate(1.6deg)" }}
            >
              <p className="font-grot text-2xl italic leading-snug text-bk-paper">
                If your photo is up here and you want it down, tell whoever is on chair
                one. It comes down that day and the gap stays.
              </p>
              <Link href="/book" className="stamp mt-6 inline-block text-bk-brass">
                Book a chair
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      <ThisIsADemonstration universe="brooklyn" />
    </>
  );
}
