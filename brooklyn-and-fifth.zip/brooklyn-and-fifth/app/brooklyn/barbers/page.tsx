import type { Metadata } from "next";
import { barbers } from "@/data/fictional-data";
import { BarberPlate } from "@/components/TeamEditorial";
import { ThisIsADemonstration } from "@/components/AgencyMarks";
import { CutLine } from "@/components/Reveal";

export const metadata: Metadata = {
  title: "The barbers",
  description: "Four chairs, four people, sixty-four years between them.",
};

export default function BarbersPage() {
  const years = barbers.reduce((n, b) => n + b.years, 0);

  return (
    <>
      <section className="tex-brick tex-grain px-5 pb-8 pt-36 sm:px-8 sm:pt-44 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          <h1 className="font-slab text-mega uppercase leading-[0.84] text-bk-paper">
            <CutLine>Meet the</CutLine>
            <CutLine delay={0.08}>
              <span className="text-bk-brass">barbers</span>
            </CutLine>
          </h1>
          <p className="mt-8 max-w-measure font-grot text-xl leading-relaxed text-bk-paper/70">
            {years} years between the four of them, and not one of them will tell you the
            others are wrong. They will tell you they would have done it differently.
          </p>
        </div>
      </section>

      <section className="tex-brick px-5 pb-24 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          {barbers.map((b, i) => (
            <BarberPlate key={b.id} p={b} index={i} />
          ))}
        </div>
      </section>

      <ThisIsADemonstration universe="brooklyn" />
    </>
  );
}
