import type { Metadata } from "next";
import { stylists } from "@/data/fictional-data";
import { StylistSpread } from "@/components/TeamEditorial";
import { ThisIsADemonstration } from "@/components/AgencyMarks";
import { CutLine } from "@/components/Reveal";

export const metadata: Metadata = {
  title: "The Fifth Edit",
  description: "The women behind the looks. Four stations, four points of view.",
};

export default function FifthTeamPage() {
  return (
    <>
      <section className="tex-stock px-5 pb-4 pt-36 sm:px-8 sm:pt-44 lg:px-12">
        <div className="mx-auto max-w-[92rem]">
          <p className="font-garamond text-xl italic text-ff-noir/50">
            The Fifth Edit, issue four
          </p>
          <h1 className="mt-4 font-didone text-mega leading-[0.84] text-ff-noir">
            <CutLine>The women behind</CutLine>
            <CutLine delay={0.08}>
              <span className="italic text-ff-rouge">the looks</span>
            </CutLine>
          </h1>
          <p className="mt-8 max-w-measure-serif font-garamond text-2xl leading-relaxed text-ff-noir/70">
            Fifty-eight years of work between four people who agree on almost nothing
            except that the consultation is the appointment and the rest is execution.
          </p>
        </div>
      </section>

      <section className="tex-stock px-5 pb-16 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-[92rem] divide-y divide-ff-noir/10">
          {stylists.map((s, i) => (
            <StylistSpread key={s.id} p={s} index={i} />
          ))}
        </div>
      </section>

      <ThisIsADemonstration universe="fifth" />
    </>
  );
}
