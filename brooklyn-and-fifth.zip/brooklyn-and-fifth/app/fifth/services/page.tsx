import type { Metadata } from "next";
import { DryerServices } from "@/components/DryerServices";
import { ThisIsADemonstration } from "@/components/AgencyMarks";

export const metadata: Metadata = {
  title: "Services",
  description: "Long appointments, short diary. The full service list at Fifth.",
};

export default function FifthServicesPage() {
  return (
    <>
      <div className="pt-20" />
      <DryerServices />
      <ThisIsADemonstration universe="fifth" />
    </>
  );
}
