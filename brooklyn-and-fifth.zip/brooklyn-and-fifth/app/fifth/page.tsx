import Image from "next/image";
import Link from "next/link";
import { FifthHero } from "@/components/FifthHero";
import { BeforeAfterSlider } from "@/components/BeforeAfterSlider";
import { ThisIsADemonstration } from "@/components/AgencyMarks";
import { Reveal, CutLine } from "@/components/Reveal";
import {
  fifthBeforeAfter,
  fifthEdit,
  fifthServices,
  stylists,
  testimonials,
} from "@/data/fictional-data";

export default function FifthHome() {
  const voices = testimonials.filter((t) => t.universe === "fifth");

  return (
    <>
      <FifthHero />

      {/* ------------------------------------------------------- the standing */}
      <section className="bg-ff-noir px-5 py-24 sm:px-8 sm:py-32 lg:px-12">
        <div className="mx-auto grid max-w-[92rem] gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <p className="font-didone text-huge leading-[0.94] text-ff-chalk">
              Four stations,
              <span className="italic text-ff-champagne"> north light </span>
              and no music.
            </p>
          </div>
          <div className="lg:col-span-4 lg:col-start-9">
            <Reveal>
              <p className="max-w-measure-serif font-garamond text-2xl leading-relaxed text-ff-chalk/70">
                We book one client per stylist per slot. If your colour needs three hours
                it gets three hours, and nobody is being processed at the basin while you
                sit in the chair.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------- the fifth edit */}
      <section className="tex-stock px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="ff-team">
        <div className="mx-auto max-w-[92rem]">
          <div className="mb-14 flex flex-wrap items-end justify-between gap-6">
            <h2 id="ff-team" className="font-didone text-colossal text-ff-noir">
              <CutLine>The women behind</CutLine>
              <CutLine delay={0.08}>
                <span className="italic text-ff-rouge">the looks</span>
              </CutLine>
            </h2>
            <Link href="/fifth/team" className="link-underline font-garamond text-xl italic text-ff-noir/70">
              Read the full edit
            </Link>
          </div>

          <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {stylists.map((s, i) => (
              <Reveal as="li" key={s.id} delay={i * 0.06}>
                <Link href="/fifth/team" className="group block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-ff-champagne/40">
                    <Image
                      src={s.portrait}
                      alt={`${s.name}, ${s.role}`}
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 24vw"
                      className="object-cover object-top grayscale transition-[filter,transform] duration-[900ms] ease-blade group-hover:scale-[1.04] group-hover:grayscale-0"
                    />
                  </div>
                  <h3 className="mt-4 font-didone text-2xl text-ff-noir">{s.name}</h3>
                  <p className="mt-1 font-garamond text-lg italic text-ff-noir/55">{s.role}</p>
                </Link>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* ---------------------------------------------------- services teaser */}
      <section className="tex-stock border-y border-ff-noir/10 px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="ff-svc">
        <div className="mx-auto grid max-w-[92rem] gap-10 lg:grid-cols-12">
          <h2 id="ff-svc" className="font-didone text-colossal text-ff-noir lg:col-span-5">
            <CutLine>What we</CutLine>
            <CutLine delay={0.08}>
              <span className="italic text-ff-rouge">do here</span>
            </CutLine>
          </h2>

          <ul className="lg:col-span-6 lg:col-start-7">
            {fifthServices.slice(0, 4).map((s) => (
              <li key={s.id} className="rule-hair py-5">
                <Link href="/fifth/services" className="group flex items-baseline justify-between gap-6">
                  <span className="font-didone text-3xl text-ff-noir transition-colors group-hover:text-ff-rouge">
                    {s.name}
                  </span>
                  <span className="shrink-0 font-garamond text-xl italic text-ff-noir/55">
                    ${s.price}
                  </span>
                </Link>
              </li>
            ))}
            <li className="pt-7">
              <Link
                href="/fifth/services"
                className="stamp inline-flex items-center gap-3 bg-ff-noir px-6 py-3.5 text-ff-chalk transition-colors hover:bg-ff-rouge"
              >
                Turn the dryer on
              </Link>
            </li>
          </ul>
        </div>
      </section>

      {/* ------------------------------------------------------ spotted on fifth */}
      <section className="tex-stock px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="ff-ba">
        <div className="mx-auto max-w-[92rem]">
          <h2 id="ff-ba" className="font-didone text-colossal text-ff-noir">
            <CutLine>Spotted on</CutLine>
            <CutLine delay={0.08}>
              <span className="italic text-ff-rouge">Fifth</span>
            </CutLine>
          </h2>
          <p className="mt-6 max-w-measure-serif font-garamond text-2xl text-ff-noir/65">
            The same head of hair, an appointment apart. Drag the handle, or give it focus
            and use the arrow keys.
          </p>

          <div className="mt-12 grid gap-12 lg:grid-cols-3 lg:gap-8">
            {fifthBeforeAfter.map((b, i) => (
              <Reveal key={b.id} delay={i * 0.08}>
                <BeforeAfterSlider item={b} universe="fifth" />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------- the edit */}
      <section className="bg-ff-noir px-5 py-24 sm:px-8 sm:py-32 lg:px-12" aria-labelledby="ff-edit">
        <div className="mx-auto max-w-[92rem]">
          <div className="mb-12 flex flex-wrap items-end justify-between gap-6">
            <h2 id="ff-edit" className="font-didone text-colossal text-ff-chalk">
              <CutLine>The Edit</CutLine>
            </h2>
            <Link href="/fifth/edit" className="link-underline font-garamond text-xl italic text-ff-champagne">
              Issue four, in full
            </Link>
          </div>

          <ul className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {fifthEdit.slice(0, 4).map((e, i) => (
              <Reveal as="li" key={e.id} delay={i * 0.05} kind="wipe">
                <div className="relative aspect-[3/4] w-full overflow-hidden bg-ff-noir">
                  <Image
                    src={e.src}
                    alt={e.alt}
                    fill
                    sizes="(max-width: 640px) 45vw, 22vw"
                    className="object-cover"
                  />
                </div>
                <p className="mt-2 font-garamond text-base italic text-ff-chalk/60">
                  {e.caption}
                </p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* -------------------------------------------------------- the voices */}
      <section className="tex-stock px-5 py-20 sm:px-8 sm:py-28 lg:px-12">
        <div className="mx-auto grid max-w-[92rem] gap-12 sm:grid-cols-2 lg:gap-20">
          {voices.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.1}>
              <blockquote>
                <p className="font-didone text-2xl italic leading-snug text-ff-noir sm:text-3xl">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <footer className="mt-5 font-garamond text-lg text-ff-noir/55">
                  {t.name}, {t.detail}
                </footer>
              </blockquote>
            </Reveal>
          ))}
        </div>
      </section>

      {/* -------------------------------------------------------- cross over */}
      <section className="tex-stock px-5 py-20 sm:px-8 lg:px-12">
        <Link
          href="/brooklyn"
          className="group mx-auto flex max-w-[92rem] flex-wrap items-center justify-between gap-6 border border-ff-noir/15 p-8 transition-colors hover:border-ff-noir/50 sm:p-12"
        >
          <div>
            <p className="font-garamond text-lg italic text-ff-rouge">The other house</p>
            <p className="mt-3 font-slab text-4xl uppercase text-ff-noir sm:text-5xl">
              Brooklyn
            </p>
            <p className="mt-2 font-grot text-xl uppercase tracking-rivet text-ff-noir/55">
              Built sharp. Stay classic.
            </p>
          </div>
          <span className="stamp flex items-center gap-3 text-ff-noir/60 transition-colors group-hover:text-ff-rouge">
            Cross the river
            <svg width="34" height="8" viewBox="0 0 34 8" fill="none" aria-hidden>
              <path d="M0 4h32M28 1l4 3-4 3" stroke="currentColor" strokeWidth="1" />
            </svg>
          </span>
        </Link>
      </section>

      <ThisIsADemonstration universe="fifth" />
    </>
  );
}
