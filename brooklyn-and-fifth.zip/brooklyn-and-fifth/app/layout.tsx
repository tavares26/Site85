import type { Metadata, Viewport } from "next";
import { fontVars } from "./fonts";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Brooklyn & Fifth — Barber & Beauty House",
    template: "%s · Brooklyn & Fifth",
  },
  description:
    "Two houses, one address book. A barbershop in Brooklyn and a beauty salon on Fifth. Demonstration site built by Manhattan Studios.",
  openGraph: {
    title: "Brooklyn & Fifth — Barber & Beauty House",
    description: "Built sharp. Stay classic. New York looks good on you.",
    type: "website",
  },
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#171715",
  colorScheme: "dark light",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={fontVars}>
      <body>
        <a
          href="#main"
          className="stamp sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-bk-brass focus:px-4 focus:py-2 focus:text-bk-ink"
        >
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
