import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./data/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Brooklyn — charcoal, coffee, brass, aged paper, wine
        bk: {
          ink: "#171715",
          coffee: "#34271E",
          brass: "#B69A6A",
          paper: "#E7DDC9",
          wine: "#711E1E",
          smoke: "#22211E",
        },
        // Fifth — black, white, cream, champagne, deep red
        ff: {
          noir: "#000000",
          chalk: "#FFFFFF",
          cream: "#F6F1E7",
          champagne: "#E3C9A8",
          rouge: "#8A1520",
          ash: "#9B958C",
        },
      },
      fontFamily: {
        slab: ["var(--font-bk-display)", "Impact", "sans-serif"],
        grot: ["var(--font-bk-body)", "system-ui", "sans-serif"],
        didone: ["var(--font-ff-display)", "Didot", "Georgia", "serif"],
        garamond: ["var(--font-ff-body)", "Georgia", "serif"],
      },
      fontSize: {
        // Editorial scale, ratio ~1.5 with fluid clamps for the display sizes
        mega: ["clamp(3.4rem, 17vw, 15rem)", { lineHeight: "0.82", letterSpacing: "-0.02em" }],
        colossal: ["clamp(2.6rem, 11vw, 9rem)", { lineHeight: "0.86", letterSpacing: "-0.015em" }],
        huge: ["clamp(2rem, 6.5vw, 5rem)", { lineHeight: "0.94" }],
        big: ["clamp(1.5rem, 3.6vw, 2.75rem)", { lineHeight: "1.05" }],
      },
      letterSpacing: {
        girder: "0.22em",
        rivet: "0.11em",
      },
      maxWidth: {
        measure: "62ch",
        "measure-serif": "72ch",
      },
      transitionTimingFunction: {
        blade: "cubic-bezier(0.22, 1, 0.36, 1)",
        drape: "cubic-bezier(0.65, 0, 0.35, 1)",
      },
      keyframes: {
        seam: {
          "0%,100%": { opacity: "0.35" },
          "50%": { opacity: "0.9" },
        },
        drift: {
          "0%": { transform: "translateX(-4%)" },
          "100%": { transform: "translateX(4%)" },
        },
      },
      animation: {
        seam: "seam 5s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};

export default config;
