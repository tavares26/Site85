import type { Variants, Transition } from "framer-motion";

export const blade: Transition = { duration: 0.9, ease: [0.22, 1, 0.36, 1] };
export const drape: Transition = { duration: 0.7, ease: [0.65, 0, 0.35, 1] };

/**
 * One orchestrated entrance per page, not a fade on every section.
 * Children stagger from a single parent so the page arrives as a sequence.
 */
export const stage: Variants = {
  hidden: {},
  shown: { transition: { staggerChildren: 0.09, delayChildren: 0.05 } },
};

export const riseLine: Variants = {
  hidden: { y: "108%" },
  shown: { y: "0%", transition: blade },
};

export const settle: Variants = {
  hidden: { opacity: 0, y: 18 },
  shown: { opacity: 1, y: 0, transition: drape },
};

export const wipe: Variants = {
  hidden: { clipPath: "inset(0 100% 0 0)" },
  shown: { clipPath: "inset(0 0% 0 0)", transition: { duration: 1.05, ease: [0.22, 1, 0.36, 1] } },
};

/** Framer's reduced-motion hook returns null on first paint, so default to false. */
export const flatten = (reduced: boolean | null, v: Variants): Variants =>
  reduced
    ? { hidden: { opacity: 1, y: 0, clipPath: "inset(0 0% 0 0)" }, shown: { opacity: 1, y: 0, clipPath: "inset(0 0% 0 0)" } }
    : v;
